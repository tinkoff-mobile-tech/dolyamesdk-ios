Dependencies needed for building TrustKit.

* RSSwizzle: https://github.com/rabovik/RSSwizzle
* domain\_registry\_provider: https://github.com/nabla-c0d3/domain-registry-provider/
