//
//  JuicyScoreFramework.h
//  JuicyScoreFramework
//
//  Created by Александр Асиненко on 11.04.2022.
//

#import <Foundation/Foundation.h>
//#import "JuicyScoreFramework-Swift.h"
//#import <JuicyScoreFramework.h>
#import "JuicyScore.h"

//! Project version number for JuicyScoreFramework.
FOUNDATION_EXPORT double JuicyScoreFrameworkVersionNumber;

//! Project version string for JuicyScoreFramework.
FOUNDATION_EXPORT const unsigned char JuicyScoreFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JuicyScoreFramework/PublicHeader.h>
